from django.contrib import admin
from app.models import Table1,Customer

# Register your models here.
admin.site.register(Table1)
admin.site.register(Customer)
