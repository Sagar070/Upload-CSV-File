from django import forms

class uploadFile(forms.Form):
    file=forms.FileField()