from django.db import models

# Create your models here.
class Table1(models.Model):
    FirstName=models.TextField(max_length=400)
    LastName=models.TextField()
    Email=models.EmailField(primary_key=True)
    
class Customer(models.Model):
    User=models.ForeignKey(Table1,on_delete=models.CASCADE)
    Phone_no=models.IntegerField()
    Gender=models.TextField(max_length=300)
    DOB=models.DateField(auto_now=False, auto_now_add=False)
    Add1=models.TextField(max_length=100)
    Add2=models.TextField(max_length=100)
    Pincode=models.IntegerField()
    state=models.TextField(max_length=100)
    country=models.TextField(max_length=100)
    

