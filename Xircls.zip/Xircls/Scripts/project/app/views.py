from django.shortcuts import render
from .forms import uploadFile
from django.http import HttpResponse

def upload_file(request):
    if request.method == 'POST':
        form = uploadFile(request.POST, request.FILES)
        if form.is_valid():

            file = request.FILES['file']
            # df = pd.read_csv(file)
            df.drop_duplicates(inplace=True)


            from .models import Table1
            for index, row in df.iterrows():
                Table1.objects.create(field1=row['Field1'], field2=row['Field2']) 


            data = Table1.objects.all()
            return render(request, 'index.html', {'data': data})
    else:
        form = uploadFile()
    return render(request, 'index.html', {'form': form})


def download_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="data.csv"'
    data = Table1.objects.all()


    writer = csv.writer(response)
    writer.writerow(['Field1', 'Field2']) 
    for item in data:
        writer.writerow([item.field1, item.field2])

    return response